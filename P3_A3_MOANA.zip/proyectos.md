
# Proyectos Agenda DIU - 2017/2018 


- (https://github.com/mchc97)               -> (http://Mchc97.github.io) 
- (https://github.com/NazaretRJ)    -> (http://NazaretRJ.github.io) 
- (https://github.com/LuisSolaRuiz) -> (http://LuisSolaRuiz.github.io)
- (https://github.com/Medfac9/DIU18) -> (https://medfac9.github.io/DIU18/index.html)
- (https://github.com/Ginfs/DIU18/blob/master/ruta.md) -> (https://francarter95.000webhostapp.com/) 
- (https://github.com/Jesus-Sheriff/DIU18) -> (https://jesus-sheriff.github.io/DIU-UXperience/) 
- (https://github.com/JaviMancilla/DIU18) -> (https://javimancilla.github.io/blank.html) 
- (https://github.com/juang3/DIU18) -> (https://juang3.github.io)+
- (https://github.com/manoloros/DIU18) -> (https://manoloros.github.io )
- (https://github.com/Taunerify/DIU18) -> (https://taunerify.github.io/DIU18/P3/index.html) 
